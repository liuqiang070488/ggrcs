#' @title A data on age and smoking rates.
#'
#' @description A data on age and smoking rates.
#'
#' @name smoke
#'
#' @docType data
#'
#' @usage data(smoke)
#'
#' @keywords datasets
#' @examples
#' data(smoke)
'smoke'
